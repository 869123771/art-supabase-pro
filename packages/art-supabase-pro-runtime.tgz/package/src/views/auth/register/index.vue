<!-- 注册页面 -->
<template>
  <div class="flex w-full h-screen">
    <LoginLeftView />

    <div class="relative flex-1">
      <AuthTopBar />

      <div class="auth-right-wrap">
        <div class="form">
          <h3 class="title">{{ $t('register.title') }}</h3>
          <p class="sub-title">{{ $t('register.subTitle') }}</p>
          <ElForm
            class="mt-7.5"
            ref="formRef"
            :model="formData"
            :rules="rules"
            label-position="top"
            :key="formKey"
          >
            <ElFormItem prop="email">
              <ElInput
                class="custom-height"
                v-model.trim="formData.email"
                name="email"
                type="email"
                inputmode="email"
                autocomplete="email"
                :aria-label="$t('register.placeholder.email')"
                :spellcheck="false"
                :placeholder="$t('register.placeholder.email')"
              />
            </ElFormItem>

            <ElFormItem prop="password">
              <ElInput
                class="custom-height"
                v-model.trim="formData.password"
                name="password"
                :placeholder="$t('register.placeholder.password')"
                type="password"
                autocomplete="new-password"
                :aria-label="$t('register.placeholder.password')"
                show-password
              />
            </ElFormItem>

            <ElFormItem prop="confirmPassword">
              <ElInput
                class="custom-height"
                v-model.trim="formData.confirmPassword"
                name="confirmPassword"
                :placeholder="$t('register.placeholder.confirmPassword')"
                type="password"
                autocomplete="new-password"
                :aria-label="$t('register.placeholder.confirmPassword')"
                @keyup.enter="handleRegister"
                show-password
              />
            </ElFormItem>

            <ElFormItem prop="agreement">
              <ElCheckbox v-model="formData.agreement">
                {{ $t('register.agreeText') }}
                <RouterLink
                  style="color: var(--theme-color); text-decoration: none"
                  to="/privacy-policy"
                  >{{ $t('register.privacyPolicy') }}</RouterLink
                >
              </ElCheckbox>
            </ElFormItem>

            <div style="margin-top: 15px">
              <ElButton
                class="w-full custom-height"
                type="primary"
                @click="handleRegister"
                :loading="loading"
                v-ripple
              >
                {{ $t('register.submitBtnText') }}
              </ElButton>
            </div>

            <div class="mt-5 text-sm text-g-600">
              <span>{{ $t('register.hasAccount') }}</span>
              <RouterLink class="text-theme" :to="{ name: 'Login' }">{{
                $t('register.toLogin')
              }}</RouterLink>
            </div>
          </ElForm>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { useI18n } from 'vue-i18n'
  import type { FormInstance, FormItemRule, FormRules } from 'element-plus'
  import type { QueryResult } from '@/types/api/response'
  import { register } from '@/api/auth'
  import { useSystemParam } from '@/hooks'
  import { useWebsiteConfig } from '@/hooks'

  defineOptions({ name: 'Register' })

  type RegisterParams = Api.Auth.RegisterParams

  interface RegisterForm {
    email: string
    password: string
    confirmPassword: string
    agreement: boolean
  }

  const REDIRECT_DELAY = 1000

  const { t, locale } = useI18n()
  const router = useRouter()
  const {
    passwordMinLength,
    loadPasswordPolicy,
    getPasswordMinLengthMessage,
    getPasswordComplexityMessage,
    validatePasswordComplexity
  } = useSystemParam()
  const { websiteConfig, loadWebsiteConfig } = useWebsiteConfig()

  const formRef = ref<FormInstance>()

  const loading = ref(false)
  const formKey = ref(0)

  // 监听语言切换，重置表单
  watch(locale, () => {
    formKey.value++
  })

  onMounted(() => {
    void loadWebsiteConfig().then(() => {
      if (!websiteConfig.value.registerEnabled) {
        ElMessage.warning('当前站点未开放注册')
        router.replace({ name: 'Login' })
      }
    })
    void loadPasswordPolicy().then(() => {
      if (formData.password) {
        void formRef.value?.validateField('password')
      }
    })
  })

  const formData = reactive<RegisterForm>({
    email: '',
    password: '',
    confirmPassword: '',
    agreement: false
  })

  /**
   * 验证密码
   * 当密码输入后，如果确认密码已填写，则触发确认密码的验证
   */
  const validatePassword: FormItemRule['validator'] = (_rule, value, callback) => {
    const password = String(value ?? '')

    if (!password) {
      callback(new Error(t('register.placeholder.password')))
      return
    }

    if (formData.confirmPassword) {
      formRef.value?.validateField('confirmPassword')
    }

    if (!validatePasswordComplexity(password)) {
      callback(new Error(getPasswordComplexityMessage(t)))
      return
    }

    callback()
  }

  /**
   * 验证确认密码
   * 检查确认密码是否与密码一致
   */
  const validateConfirmPassword: FormItemRule['validator'] = (_rule, value, callback) => {
    const confirmPassword = String(value ?? '')

    if (!confirmPassword) {
      callback(new Error(t('register.rule.confirmPasswordRequired')))
      return
    }

    if (confirmPassword !== formData.password) {
      callback(new Error(t('register.rule.passwordMismatch')))
      return
    }

    callback()
  }

  /**
   * 验证用户协议
   * 确保用户已勾选同意协议
   */
  const validateAgreement: FormItemRule['validator'] = (_rule, value, callback) => {
    if (!value) {
      callback(new Error(t('register.rule.agreementRequired')))
      return
    }
    callback()
  }

  const rules = computed<FormRules<RegisterForm>>(() => ({
    password: [
      { required: true, validator: validatePassword, trigger: 'change' },
      {
        min: passwordMinLength.value,
        message: getPasswordMinLengthMessage(t),
        trigger: 'change'
      }
    ],
    email: [{ type: 'email', trigger: 'change', message: t('register.rule.emailIncorrect') }],
    confirmPassword: [{ required: true, validator: validateConfirmPassword, trigger: 'change' }],
    agreement: [{ validator: validateAgreement, trigger: 'change' }]
  }))

  /**
   * 注册用户
   * 验证表单后提交注册请求
   */
  const handleRegister = async () => {
    if (!formRef.value) return
    if (!websiteConfig.value.registerEnabled) {
      ElMessage.warning('当前站点未开放注册')
      router.replace({ name: 'Login' })
      return
    }

    try {
      await formRef.value.validate()
      loading.value = true

      const params: RegisterParams = {
        email: formData.email,
        password: formData.password
      }
      const { data } = (await registerAndLink(params)) as QueryResult<unknown>
      if (data) {
        toLogin()
      }
    } catch (error) {
      console.error('表单验证失败:', error)
    } finally {
      loading.value = false
    }
  }

  const registerAndLink = async (payload: RegisterParams): Promise<QueryResult<unknown>> => {
    return register(payload)
  }

  /**
   * 跳转到登录页面
   */
  const toLogin = () => {
    setTimeout(() => {
      router.push({ name: 'Login' })
    }, REDIRECT_DELAY)
  }
</script>

<style scoped>
  @import '../login/style.css';
</style>
