create function current_is_super() returns boolean
    stable
    security definer
    language sql
as
$$
  SELECT current_setting('is_superuser', true) = 'on' OR 
         EXISTS (
           SELECT 1 
           FROM pg_roles 
           WHERE rolname = current_user 
           AND rolsuper = true
         );
$$;

alter function current_is_super() owner to postgres;

grant execute on function current_is_super() to anon;

grant execute on function current_is_super() to authenticated;

grant execute on function current_is_super() to service_role;

