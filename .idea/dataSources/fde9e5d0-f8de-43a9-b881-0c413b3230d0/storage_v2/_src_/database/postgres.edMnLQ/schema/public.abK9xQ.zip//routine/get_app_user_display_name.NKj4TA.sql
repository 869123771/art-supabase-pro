create function get_app_user_display_name() returns text
    security definer
    language sql
as
$$
  -- 1) Prefer explicit session setting (set within the current transaction/session)
  SELECT current_setting('myapp.current_user_display', true)
  WHERE current_setting('myapp.current_user_display', true) IS NOT NULL
  UNION ALL
  -- 2) Otherwise, try to resolve from auth.uid(), prefer user_email, then user_name, then nick_name
  SELECT COALESCE(NULLIF(user_email, ''), NULLIF(user_name, ''), NULLIF(nick_name, ''))
  FROM public.app_users
  WHERE auth_user_id = (SELECT auth.uid())
  LIMIT 1;
$$;

alter function get_app_user_display_name() owner to postgres;

grant execute on function get_app_user_display_name() to service_role;

