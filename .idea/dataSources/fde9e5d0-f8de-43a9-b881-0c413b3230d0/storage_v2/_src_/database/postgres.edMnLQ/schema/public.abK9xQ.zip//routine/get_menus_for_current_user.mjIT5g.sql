create function get_menus_for_current_user() returns jsonb
    stable
    security definer
    language plpgsql
as
$$DECLARE
  v_cur_uid uuid := (SELECT auth.uid());
  v_role_ids uuid[] := '{}';
  v_menu_ids uuid[] := '{}';
  v_rec RECORD;
  v_nodes jsonb := '[]'::jsonb;
  v_node_map jsonb := '{}'::jsonb;
  v_roots jsonb := '[]'::jsonb;
  v_flat jsonb := '[]'::jsonb;
  v_key text;
  v_parent_id uuid;
  v_tmp jsonb;
BEGIN
  IF v_cur_uid IS NULL THEN
    RETURN jsonb_build_object('flat', v_flat, 'tree', v_roots);
  END IF;

  SELECT ARRAY_REMOVE(ARRAY_AGG(r.id), NULL) INTO v_role_ids
  FROM public.app_users au
  JOIN public.roles r ON r.role_code = ANY(au.user_roles)
  WHERE au.auth_user_id = v_cur_uid;

  IF v_role_ids IS NULL OR array_length(v_role_ids,1) IS NULL THEN
    RETURN jsonb_build_object('flat', v_flat, 'tree', v_roots);
  END IF;

  SELECT ARRAY_REMOVE(ARRAY_AGG(DISTINCT rm.menu_id), NULL) INTO v_menu_ids
  FROM public.role_menus rm
  WHERE rm.role_id = ANY(v_role_ids);

  IF v_menu_ids IS NULL OR array_length(v_menu_ids,1) IS NULL THEN
    RETURN jsonb_build_object('flat', v_flat, 'tree', v_roots);
  END IF;

  -- build flat array and node_map
  FOR v_rec IN
    SELECT m.id, m.parent_id, m.name, m.path, m.component, m.meta, m.sort , m.type 
    FROM public.menus m
    WHERE m.id = ANY(v_menu_ids)
    ORDER BY m.sort NULLS LAST, m.id
  LOOP
    v_flat := v_flat || to_jsonb(jsonb_build_object(
      'id', v_rec.id,
      'parentId', v_rec.parent_id,
      'name', v_rec.name,
      'path', v_rec.path,
      'component', v_rec.component,
      'meta', v_rec.meta,
      'sort', v_rec.sort,
      'type', v_rec.type
    ));

    -- create node with empty children; use id::text as key
    v_node_map := v_node_map || jsonb_build_object(v_rec.id::text, jsonb_build_object(
      'id', v_rec.id,
      'parentId', v_rec.parent_id,
      'name', v_rec.name,
      'path', v_rec.path,
      'component', v_rec.component,
      'meta', v_rec.meta,
      'sort', v_rec.sort,
      'type', v_rec.type,
      'children', '[]'::jsonb
    ));
  END LOOP;

  -- Build new_map with empty children
  DECLARE
    v_new_map jsonb := '{}'::jsonb;
    v_k text;
    v_v jsonb;
    v_pid text;
    v_children jsonb;
  BEGIN
    FOR v_k IN SELECT jsonb_object_keys(v_node_map)
    LOOP
      v_v := v_node_map -> v_k;
      v_new_map := v_new_map || jsonb_build_object(v_k, (v_v - 'children') || jsonb_build_object('children', '[]'::jsonb));
    END LOOP;

    -- attach children to parents in new_map
    FOR v_k IN SELECT jsonb_object_keys(v_node_map)
    LOOP
      v_v := v_node_map -> v_k;
      IF v_v->>'parentId' IS NOT NULL AND v_new_map ? (v_v->>'parentId') THEN
        v_pid := v_v->>'parentId';
        v_children := (v_new_map -> v_pid) -> 'children';
        v_children := v_children || (v_new_map -> v_k);
        v_new_map := jsonb_set(v_new_map, ARRAY[v_pid], (v_new_map -> v_pid) - 'children' || jsonb_build_object('children', v_children));
      END IF;
    END LOOP;

    -- collect roots from new_map
    v_roots := '[]'::jsonb;
    FOR v_k IN SELECT jsonb_object_keys(v_new_map)
    LOOP
      v_v := v_new_map -> v_k;
      IF v_v->>'parentId' IS NULL OR NOT v_new_map ? (v_v->>'parentId') THEN
        v_roots := v_roots || v_v;
      END IF;
    END LOOP;

    v_node_map := v_new_map;
  END;

  RETURN jsonb_build_object('flat', v_flat, 'tree', v_roots);
END;$$;

alter function get_menus_for_current_user() owner to postgres;

grant execute on function get_menus_for_current_user() to anon;

grant execute on function get_menus_for_current_user() to authenticated;

grant execute on function get_menus_for_current_user() to service_role;

