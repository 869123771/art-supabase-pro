create function trg_set_update_time_and_by() returns trigger
    security definer
    language plpgsql
as
$$
BEGIN
  -- set update_time if column exists
  BEGIN
    NEW.update_time := now();
  EXCEPTION WHEN undefined_column THEN
    NULL;
  END;

  -- set update_by if column exists and is null/empty
  BEGIN
    IF NEW.update_by IS NULL OR NEW.update_by = '' THEN
      NEW.update_by := get_app_user_display_name();
    END IF;
  EXCEPTION WHEN undefined_column THEN
    NULL;
  END;

  RETURN NEW;
END;
$$;

alter function trg_set_update_time_and_by() owner to postgres;

grant execute on function trg_set_update_time_and_by() to anon;

grant execute on function trg_set_update_time_and_by() to authenticated;

grant execute on function trg_set_update_time_and_by() to service_role;

