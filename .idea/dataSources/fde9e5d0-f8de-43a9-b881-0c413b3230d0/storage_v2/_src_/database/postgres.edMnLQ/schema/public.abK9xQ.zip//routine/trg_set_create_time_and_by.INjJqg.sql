create function trg_set_create_time_and_by() returns trigger
    security definer
    language plpgsql
as
$$
BEGIN
  -- set create_time if column exists and is null
  IF TG_ARGV[0] = 'true' THEN
    BEGIN
      IF NEW.create_time IS NULL THEN
        NEW.create_time := now();
      END IF;
    EXCEPTION WHEN undefined_column THEN
      NULL;
    END;
  END IF;

  -- set create_by if column exists and is null
  -- Use auth.jwt() ->> 'email' as the source of truth
  IF TG_ARGV[1] = 'true' THEN
    BEGIN
      IF NEW.create_by IS NULL OR NEW.create_by = '' THEN
        -- prefer JWT email; fallback to 'unknown' if not present
        NEW.create_by := COALESCE((auth.jwt() ->> 'email'), 'unknown');
      END IF;
    EXCEPTION WHEN undefined_column THEN
      NULL;
    END;
  END IF;

  RETURN NEW;
END;
$$;

alter function trg_set_create_time_and_by() owner to postgres;

grant execute on function trg_set_create_time_and_by() to anon;

grant execute on function trg_set_create_time_and_by() to authenticated;

grant execute on function trg_set_create_time_and_by() to service_role;

