create function current_creator() returns text
    security definer
    SET search_path = public
    language sql
as
$$
  -- 优先返回调用者的 email（从 JWT 获取）
  -- 如果 JWT 里没有 email，再尝试从 app_users.create_by 获取
  select coalesce(
    (auth.jwt() ->> 'email'),
    (select au.create_by
     from app_users au
     where au.auth_user_id = auth.uid()
     limit 1)
  );
$$;

alter function current_creator() owner to postgres;

grant execute on function current_creator() to anon;

grant execute on function current_creator() to authenticated;

grant execute on function current_creator() to service_role;

