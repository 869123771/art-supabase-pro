create function set_role_menus(p_role_id uuid, p_menu_ids uuid[]) returns void
    language plpgsql
as
$$
BEGIN
  -- 删除已有映射
  DELETE FROM public.role_menus WHERE role_id = p_role_id;

  -- 若传入菜单 id 数组则插入去重后的记录
  IF array_length(p_menu_ids, 1) IS NOT NULL THEN
    INSERT INTO public.role_menus (role_id, menu_id)
    SELECT p_role_id, m
    FROM (
      SELECT DISTINCT unnest(p_menu_ids) AS m
    ) s
    ON CONFLICT DO NOTHING;
  END IF;
END;
$$;

alter function set_role_menus(uuid, uuid[]) owner to postgres;

grant execute on function set_role_menus(uuid, uuid[]) to anon;

grant execute on function set_role_menus(uuid, uuid[]) to authenticated;

grant execute on function set_role_menus(uuid, uuid[]) to service_role;

