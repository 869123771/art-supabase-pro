create function sync_delete_app_user_on_auth_delete() returns trigger
    security definer
    language plpgsql
as
$$
BEGIN
  DELETE FROM public.app_users
  WHERE auth_user_id = OLD.id;

  RETURN OLD;
END;
$$;

alter function sync_delete_app_user_on_auth_delete() owner to postgres;

grant execute on function sync_delete_app_user_on_auth_delete() to anon;

grant execute on function sync_delete_app_user_on_auth_delete() to authenticated;

grant execute on function sync_delete_app_user_on_auth_delete() to service_role;

