create function get_database_metadata_all() returns jsonb
    security definer
    language plpgsql
as
$$
DECLARE
  v_result jsonb;
  v_schemas jsonb;
  v_tables jsonb;
  v_columns jsonb;
  v_functions jsonb;
BEGIN
  -- 获取所有 schemas
  SELECT jsonb_agg(schema_name ORDER BY schema_name)
  INTO v_schemas
  FROM information_schema.schemata
  WHERE schema_name NOT IN ('pg_catalog', 'information_schema', 'pg_toast', 'pg_temp_1', 'pg_toast_temp_1');

  -- 获取所有表信息
  SELECT jsonb_agg(
    jsonb_build_object(
      'tableSchema', table_schema,
      'tableName', table_name
    )
    ORDER BY table_schema, table_name
  )
  INTO v_tables
  FROM information_schema.tables
  WHERE table_schema NOT IN ('pg_catalog', 'information_schema', 'pg_toast')
    AND table_type = 'BASE TABLE';

  -- 获取所有列信息
  SELECT jsonb_agg(
    jsonb_build_object(
      'tableSchema', table_schema,
      'tableName', table_name,
      'columnName', column_name,
      'dataType', data_type,
      'isNullable', is_nullable,
      'ordinalPosition', ordinal_position
    )
    ORDER BY table_schema, table_name, ordinal_position
  )
  INTO v_columns
  FROM information_schema.columns
  WHERE table_schema NOT IN ('pg_catalog', 'information_schema', 'pg_toast');

  -- 获取所有函数信息
  SELECT jsonb_agg(
    jsonb_build_object(
      'routineSchema', routine_schema,
      'routineName', routine_name,
      'returnType', data_type
    )
    ORDER BY routine_schema, routine_name
  )
  INTO v_functions
  FROM information_schema.routines
  WHERE routine_schema NOT IN ('pg_catalog', 'information_schema', 'pg_toast')
    AND routine_type = 'FUNCTION';

  -- 构建返回结果
  v_result := jsonb_build_object(
    'schemas', COALESCE(v_schemas, '[]'::jsonb),
    'tables', COALESCE(v_tables, '[]'::jsonb),
    'columns', COALESCE(v_columns, '[]'::jsonb),
    'functions', COALESCE(v_functions, '[]'::jsonb)
  );

  RETURN v_result;
END;
$$;

alter function get_database_metadata_all() owner to postgres;

grant execute on function get_database_metadata_all() to anon;

grant execute on function get_database_metadata_all() to authenticated;

grant execute on function get_database_metadata_all() to service_role;

