create function clean_role_menus_on_role_delete() returns trigger
    security definer
    language plpgsql
as
$$
BEGIN
  DELETE FROM public.role_menus WHERE role_id = OLD.id;
  RETURN OLD;
END;
$$;

alter function clean_role_menus_on_role_delete() owner to postgres;

grant execute on function clean_role_menus_on_role_delete() to service_role;

