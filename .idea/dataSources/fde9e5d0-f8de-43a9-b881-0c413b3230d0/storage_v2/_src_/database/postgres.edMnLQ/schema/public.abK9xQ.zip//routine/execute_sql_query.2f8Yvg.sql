create function execute_sql_query(sql_query text) returns jsonb
    security definer
    language plpgsql
as
$$
DECLARE
  v_result jsonb;
  v_rows jsonb;
  v_columns jsonb;
  v_command_tag text;
  v_row_count integer := 0;
  v_start_time timestamp with time zone;
  v_end_time timestamp with time zone;
  v_duration_ms numeric;
  v_notices text[] := ARRAY[]::text[];
  v_warnings text[] := ARRAY[]::text[];
  v_query_upper text;
  v_error_message text;
  v_sql_state text;
  v_sql_err_msg text;
  v_detail text;
  v_sql_lines text[];
  v_line_num integer;
  v_found_line boolean := false;
  v_line_content text;
  v_identifier text;
  v_col_rec record;
  v_col_info jsonb;
  v_col_name text;
  v_col_value jsonb;
  v_col_type text;
BEGIN
  -- 记录开始时间
  v_start_time := clock_timestamp();
  v_query_upper := upper(trim(sql_query));
  
  -- 将 SQL 查询按行分割，用于后续的 LINE 信息提取
  v_sql_lines := string_to_array(sql_query, E'\n');

  -- 检查是否为 SELECT 查询
  IF v_query_upper LIKE 'SELECT%' OR v_query_upper LIKE 'WITH%' THEN
    -- 对于 SELECT 查询，使用动态 SQL 转换为 JSON
    BEGIN
      -- 执行查询获取结果
      EXECUTE format('SELECT jsonb_agg(row_to_json(t)) FROM (%s) t', sql_query) INTO v_rows;
      
      -- 如果结果为 NULL（没有行），设置为空数组
      IF v_rows IS NULL THEN
        v_rows := '[]'::jsonb;
      END IF;
      
      v_row_count := jsonb_array_length(v_rows);
      v_command_tag := format('SELECT %s', v_row_count);
      
      -- 获取列信息
      v_columns := '[]'::jsonb;
      
      -- 如果有数据行，从第一行获取列名和类型信息
      IF v_row_count > 0 THEN
        DECLARE
          v_first_row jsonb;
          v_col_info_item jsonb;
        BEGIN
          v_first_row := v_rows->0;
          
          -- 遍历第一行的所有键（列名）
          FOR v_col_name, v_col_value IN SELECT * FROM jsonb_each(v_first_row)
          LOOP
            -- 根据值的类型推断 PostgreSQL 类型
            v_col_type := CASE
              WHEN jsonb_typeof(v_col_value) = 'null' THEN 'unknown'
              WHEN jsonb_typeof(v_col_value) = 'boolean' THEN 'boolean'
              WHEN jsonb_typeof(v_col_value) = 'number' THEN 
                CASE 
                  WHEN v_col_value::text ~ '^-?[0-9]+$' THEN 'integer'
                  ELSE 'numeric'
                END
              WHEN jsonb_typeof(v_col_value) = 'string' THEN
                CASE
                  WHEN v_col_value::text ~ '^\d{4}-\d{2}-\d{2}' THEN 'date'
                  WHEN v_col_value::text ~ '^\d{4}-\d{2}-\d{2}.*\d{2}:\d{2}:\d{2}' THEN 'timestamp'
                  ELSE 'text'
                END
              WHEN jsonb_typeof(v_col_value) = 'object' THEN 'jsonb'
              WHEN jsonb_typeof(v_col_value) = 'array' THEN 'array'
              ELSE 'text'
            END;
            
            -- 构建列信息对象
            v_col_info_item := jsonb_build_object(
              'name', v_col_name,
              'type', v_col_type,
              'nullable', true,  -- 默认值
              'jsType', CASE 
                WHEN v_col_type IN ('integer', 'numeric', 'bigint', 'smallint', 'real', 'double precision') THEN 'number'
                WHEN v_col_type = 'boolean' THEN 'boolean'
                WHEN v_col_type IN ('date', 'timestamp', 'timestamptz', 'time', 'timetz') THEN 'date'
                WHEN v_col_type IN ('json', 'jsonb') THEN 'json'
                ELSE 'string'
              END,
              'description', NULL
            );
            
            v_columns := v_columns || jsonb_build_array(v_col_info_item);
          END LOOP;
        END;
      END IF;
      
      -- 尝试从查询结果中获取更详细的列信息
      -- 使用 pg_catalog 查询列的描述信息
      -- 注意：这需要知道表名，对于复杂查询可能不适用
      DECLARE
        v_table_schema text;
        v_table_name text;
        v_table_match text[];
        v_col_descriptions jsonb;
      BEGIN
        -- 尝试从 SQL 中提取表名（简单匹配 FROM 子句）
        -- 匹配: FROM schema.table 或 FROM table
        v_table_match := regexp_match(sql_query, E'(?i)\\s+FROM\\s+(?:([a-z_][a-z0-9_]*)\\.)?([a-z_][a-z0-9_]*)', 'i');
        
        IF v_table_match IS NOT NULL THEN
          v_table_schema := COALESCE(NULLIF(v_table_match[1], ''), 'public');
          v_table_name := v_table_match[2];
          
          -- 查询列的描述信息
          FOR v_col_rec IN
            SELECT 
              a.attname as column_name,
              pg_catalog.format_type(a.atttypid, a.atttypmod) as data_type,
              a.attnotnull as is_not_null,
              COALESCE(d.description, '') as column_comment
            FROM pg_catalog.pg_attribute a
            JOIN pg_catalog.pg_class c ON c.oid = a.attrelid
            JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
            LEFT JOIN pg_catalog.pg_description d ON d.objoid = c.oid AND d.objsubid = a.attnum
            WHERE n.nspname = v_table_schema
              AND c.relname = v_table_name
              AND a.attnum > 0
              AND NOT a.attisdropped
            ORDER BY a.attnum
          LOOP
            -- 更新对应列的信息
            v_columns := (
              SELECT jsonb_agg(
                CASE 
                  WHEN col->>'name' = v_col_rec.column_name THEN
                    jsonb_build_object(
                      'name', v_col_rec.column_name,
                      'type', split_part(v_col_rec.data_type, '(', 1),  -- 移除长度信息
                      'fullType', v_col_rec.data_type,
                      'nullable', NOT v_col_rec.is_not_null,
                      'jsType', CASE 
                        WHEN v_col_rec.data_type LIKE '%int%' OR v_col_rec.data_type LIKE '%numeric%' OR v_col_rec.data_type LIKE '%float%' OR v_col_rec.data_type LIKE '%double%' THEN 'number'
                        WHEN v_col_rec.data_type LIKE '%bool%' THEN 'boolean'
                        WHEN v_col_rec.data_type LIKE '%date%' OR v_col_rec.data_type LIKE '%time%' THEN 'date'
                        WHEN v_col_rec.data_type LIKE '%json%' THEN 'json'
                        ELSE 'string'
                      END,
                      'description', NULLIF(v_col_rec.column_comment, '')
                    )
                  ELSE col
                END
              )
              FROM jsonb_array_elements(v_columns) AS col
            );
          END LOOP;
        END IF;
      END;
      
    EXCEPTION
      WHEN OTHERS THEN
        -- 获取详细的错误信息
        GET STACKED DIAGNOSTICS
          v_sql_state = RETURNED_SQLSTATE,
          v_sql_err_msg = MESSAGE_TEXT,
          v_detail = PG_EXCEPTION_DETAIL;
        
        -- 构建错误消息，格式与 Supabase 一致
        v_error_message := format('ERROR: %s: %s', v_sql_state, v_sql_err_msg);
        
        -- 尝试从错误消息中提取引用的标识符（表名、列名等）
        v_identifier := (regexp_match(v_sql_err_msg, E'"([^"]+)"'))[1];
        
        -- 如果找到了标识符，在 SQL 查询中查找包含该标识符的行
        IF v_identifier IS NOT NULL THEN
          FOR v_line_num IN 1..array_length(v_sql_lines, 1) LOOP
            v_line_content := v_sql_lines[v_line_num];
            
            IF v_line_content LIKE '%' || v_identifier || '%' THEN
              v_error_message := v_error_message || E'\n' || 
                format('LINE %s: %s', v_line_num, trim(v_line_content)) || E'\n' ||
                repeat(' ', greatest(5 + length(v_line_num::text) + 2, 0)) || '^';
              v_found_line := true;
              EXIT;
            END IF;
          END LOOP;
        END IF;
        
        IF NOT v_found_line THEN
          IF v_detail IS NOT NULL AND v_detail != '' THEN
            v_error_message := v_error_message || E'\n' || v_detail;
          END IF;
        END IF;
        
        RETURN jsonb_build_object(
          'error', true,
          'error_message', v_error_message,
          'sql_state', v_sql_state,
          'duration_ms', round(EXTRACT(EPOCH FROM (clock_timestamp() - v_start_time)) * 1000::numeric, 2)
        );
    END;
    
  ELSIF v_query_upper LIKE 'INSERT%' THEN
    BEGIN
      EXECUTE sql_query;
      GET DIAGNOSTICS v_row_count = ROW_COUNT;
      v_command_tag := format('INSERT 0 %s', v_row_count);
      v_rows := '[]'::jsonb;
      v_columns := '[]'::jsonb;
    EXCEPTION
      WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
          v_sql_state = RETURNED_SQLSTATE,
          v_sql_err_msg = MESSAGE_TEXT,
          v_detail = PG_EXCEPTION_DETAIL;
        v_error_message := format('ERROR: %s: %s', v_sql_state, v_sql_err_msg);
        IF v_detail IS NOT NULL AND v_detail != '' THEN
          v_error_message := v_error_message || E'\n' || v_detail;
        END IF;
        RETURN jsonb_build_object(
          'error', true,
          'error_message', v_error_message,
          'sql_state', v_sql_state,
          'duration_ms', round(EXTRACT(EPOCH FROM (clock_timestamp() - v_start_time)) * 1000::numeric, 2)
        );
    END;
    
  ELSIF v_query_upper LIKE 'UPDATE%' THEN
    BEGIN
      EXECUTE sql_query;
      GET DIAGNOSTICS v_row_count = ROW_COUNT;
      v_command_tag := format('UPDATE %s', v_row_count);
      v_rows := '[]'::jsonb;
      v_columns := '[]'::jsonb;
    EXCEPTION
      WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
          v_sql_state = RETURNED_SQLSTATE,
          v_sql_err_msg = MESSAGE_TEXT,
          v_detail = PG_EXCEPTION_DETAIL;
        v_error_message := format('ERROR: %s: %s', v_sql_state, v_sql_err_msg);
        IF v_detail IS NOT NULL AND v_detail != '' THEN
          v_error_message := v_error_message || E'\n' || v_detail;
        END IF;
        RETURN jsonb_build_object(
          'error', true,
          'error_message', v_error_message,
          'sql_state', v_sql_state,
          'duration_ms', round(EXTRACT(EPOCH FROM (clock_timestamp() - v_start_time)) * 1000::numeric, 2)
        );
    END;
    
  ELSIF v_query_upper LIKE 'DELETE%' THEN
    BEGIN
      EXECUTE sql_query;
      GET DIAGNOSTICS v_row_count = ROW_COUNT;
      v_command_tag := format('DELETE %s', v_row_count);
      v_rows := '[]'::jsonb;
      v_columns := '[]'::jsonb;
    EXCEPTION
      WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
          v_sql_state = RETURNED_SQLSTATE,
          v_sql_err_msg = MESSAGE_TEXT,
          v_detail = PG_EXCEPTION_DETAIL;
        v_error_message := format('ERROR: %s: %s', v_sql_state, v_sql_err_msg);
        IF v_detail IS NOT NULL AND v_detail != '' THEN
          v_error_message := v_error_message || E'\n' || v_detail;
        END IF;
        RETURN jsonb_build_object(
          'error', true,
          'error_message', v_error_message,
          'sql_state', v_sql_state,
          'duration_ms', round(EXTRACT(EPOCH FROM (clock_timestamp() - v_start_time)) * 1000::numeric, 2)
        );
    END;
    
  ELSE
    BEGIN
      EXECUTE sql_query;
      GET DIAGNOSTICS v_row_count = ROW_COUNT;
      v_command_tag := upper(split_part(trim(sql_query), ' ', 1));
      v_rows := '[]'::jsonb;
      v_columns := '[]'::jsonb;
    EXCEPTION
      WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
          v_sql_state = RETURNED_SQLSTATE,
          v_sql_err_msg = MESSAGE_TEXT,
          v_detail = PG_EXCEPTION_DETAIL;
        v_error_message := format('ERROR: %s: %s', v_sql_state, v_sql_err_msg);
        IF v_detail IS NOT NULL AND v_detail != '' THEN
          v_error_message := v_error_message || E'\n' || v_detail;
        END IF;
        RETURN jsonb_build_object(
          'error', true,
          'error_message', v_error_message,
          'sql_state', v_sql_state,
          'duration_ms', round(EXTRACT(EPOCH FROM (clock_timestamp() - v_start_time)) * 1000::numeric, 2)
        );
    END;
  END IF;
  
  -- 记录结束时间
  v_end_time := clock_timestamp();
  v_duration_ms := EXTRACT(EPOCH FROM (v_end_time - v_start_time)) * 1000;
  
  -- 构建返回结果
  v_result := jsonb_build_object(
    'rows', COALESCE(v_rows, '[]'::jsonb),
    'columns', COALESCE(v_columns, '[]'::jsonb),
    'command_tag', v_command_tag,
    'row_count', v_row_count,
    'duration_ms', round(v_duration_ms::numeric, 2),
    'notices', v_notices,
    'warnings', v_warnings
  );
  
  RETURN v_result;
  
EXCEPTION
  WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS
      v_sql_state = RETURNED_SQLSTATE,
      v_sql_err_msg = MESSAGE_TEXT,
      v_detail = PG_EXCEPTION_DETAIL;
    
    v_error_message := format('ERROR: %s: %s', v_sql_state, v_sql_err_msg);
    
    IF v_detail IS NOT NULL AND v_detail != '' THEN
      v_error_message := v_error_message || E'\n' || v_detail;
    END IF;
    
    RETURN jsonb_build_object(
      'error', true,
      'error_message', v_error_message,
      'sql_state', v_sql_state,
      'duration_ms', round(EXTRACT(EPOCH FROM (clock_timestamp() - v_start_time)) * 1000::numeric, 2)
    );
END;
$$;

alter function execute_sql_query(text) owner to postgres;

grant execute on function execute_sql_query(text) to anon;

grant execute on function execute_sql_query(text) to authenticated;

grant execute on function execute_sql_query(text) to service_role;

